package com.bookeshopping.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bookeshopping.bean.Login;
//import com.bookeshopping.service.BookService;
import com.bookeshopping.service.LoginService;
//import com.bookeshopping.service.ProductService;

public class LoginController {
	@Autowired
	private LoginService loginService;

	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView validateUser(@ModelAttribute Login login,HttpSession httpSession) 
	{
		
		ModelAndView modelAndView = new ModelAndView();

		if(loginService.authenticateUser(login)!=null)
			{
			
					if(loginService.getUserType(login).equals("A"))
					{
					modelAndView.addObject("user", loginService.authenticateUser(login));
					httpSession.setAttribute("user", loginService.authenticateUser(login));
					
					modelAndView.setViewName("Admin-ListProducts");
					}
					else
					{
						modelAndView.addObject("user", loginService.authenticateUser(login));
						httpSession.setAttribute("user", loginService.authenticateUser(login));
					
					}
		}
				
				else
				{
					modelAndView.addObject("invalidPassword", "Invalid Password");
				}		
		}
			
		
	}
	else
	{
		System.out.println("invalid UserName");
		modelAndView.addObject("invalidUser", "Invalid Username");
		modelAndView.setViewName("Admin-Login");
	}
	return modelAndView;
	}
	
	//LogoutController
	@RequestMapping(value="LogoutController", method=RequestMethod.GET)
	public ModelAndView sortProductPage(HttpSession httpSession)
	{
		ModelAndView modelAndView = new ModelAndView();
		
		httpSession.removeAttribute("user");
		modelAndView.addObject("logoutMessage", "Logout Successful");
		httpSession.invalidate();
		modelAndView.setViewName("login.html");
	
		
		return modelAndView;
	}
	
	
}
