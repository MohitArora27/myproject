package com.bookeshopping.dao;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bookeshopping.bean.UserRegistration;

@Repository("RegistrationDAO")
public class RegistrationDAOImpl implements RegistrationDAO{
@Autowired
@Qualifier("sessionFactory")
SessionFactory sessionFactory;
@Transactional
public String setUserDetails(UserRegistration userRegistration)
{
Session session=null;
System.out.println(userRegistration);
try {
	session=sessionFactory.getCurrentSession();
	session.save(userRegistration);
	return "Success";
}
catch (Exception e)
{
	e.printStackTrace();
}
return null;
}
}
