package com.bookeshopping.dao;

import com.bookeshopping.bean.Login;

public interface LoginDAO {
	public Login authenticateUser(Login login);
	public String getUserType(Login login);
//	public boolean authenticate(String userName,String password);
//	
}
