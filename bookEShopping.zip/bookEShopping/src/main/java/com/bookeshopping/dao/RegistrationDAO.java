package com.bookeshopping.dao;
import com.bookeshopping.bean.UserRegistration;

public interface RegistrationDAO {
	public  String setUserDetails(UserRegistration userRegistration);
}
