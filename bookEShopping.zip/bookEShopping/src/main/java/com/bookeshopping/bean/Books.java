package com.bookeshopping.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "books")
@Table(name = "books_table")
public class Books {
//private Category cat;
@Id
@Column(name = "bookId")
private String bookId;
@Column(name = "bookName")
private String bookName;
@Column(name = "price")
private String price;
@Column(name = "catName")
public String catName;
@Column(name = "availability")
private String availability;
@Column(name = "binding")
private String binding;
@Column(name = "language")
private String language;
@Column(name = "authorName")
private String authorName;
@Column(name = "publisherName")
private String publisherName;
@Column(name = "deliveryDate")
private String deliveryDate;
/*@ManyToOne
@JoinColumn(name="catId")
private Books book;
*/
public Books() {
	// TODO Auto-generated constructor stub
}
public String getCatName() {
	return catName;
}
public void setCatName(String catName) {
	this.catName = catName;
}
@Override
public String toString() {
	return "Books [bookId=" + bookId + ", bookName=" + bookName + ", price=" + price + ", catName=" + catName
			+ ", availability=" + availability + ", binding=" + binding + ", language=" + language + ", authorName="
			+ authorName + ", publisherName=" + publisherName + ", deliveryDate=" + deliveryDate + "]";
}


public Books(String bookId, String bookName, String price, String catName, String availability, String binding,
		String language, String authorName, String publisherName, String deliveryDate) {
	super();
	this.bookId = bookId;
	this.bookName = bookName;
	this.price = price;
	this.catName = catName;
	this.availability = availability;
	this.binding = binding;
	this.language = language;
	this.authorName = authorName;
	this.publisherName = publisherName;
	this.deliveryDate = deliveryDate;
}
public String getBookId() {
	return bookId;
}
public void setBookId(String bookId) {
	this.bookId = bookId;
}
public String getBookName() {
	return bookName;
}
public void setBookName(String bookName) {
	this.bookName = bookName;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public String getAvailability() {
	return availability;
}
public void setAvailability(String availability) {
	this.availability = availability;
}
public String getBinding() {
	return binding;
}
public void setBinding(String binding) {
	this.binding = binding;
}
public String getLanguage() {
	return language;
}
public void setLanguage(String language) {
	this.language = language;
}
public String getAuthorName() {
	return authorName;
}
public void setAuthorName(String authorName) {
	this.authorName = authorName;
}
public String getPublisherName() {
	return publisherName;
}
public void setPublisherName(String publisherName) {
	this.publisherName = publisherName;
}
public String getDeliveryDate() {
	return deliveryDate;
}
public void setDeliveryDate(String deliveryDate) {
	this.deliveryDate = deliveryDate;
}


}
