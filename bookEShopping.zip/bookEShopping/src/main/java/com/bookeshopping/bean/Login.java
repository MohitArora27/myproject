package com.bookeshopping.bean;
import javax.persistence.*;
@Entity(name="Login")
@Table(name="Login")
public class Login {
@Id
@Column(name="emailid")
private String emailid;
@Column(name = "password")
private String password;
@Column(name="userType")
private String userType;
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getUserType() {
	return userType;
}
public void setUserType(String userType) {
	this.userType = userType;
}
@Override
public String toString() {
	return "Login [emailid=" + emailid + ", password=" + password + ", userType=" + userType + "]";
}
public Login() {
	super();
	// TODO Auto-generated constructor stub
}
public Login(String emailid, String password, String userType) {
	super();
	this.emailid = emailid;
	this.password = password;
	this.userType = userType;
}


}
