package com.bookeshopping.bean;

public class AddToCart {

}
