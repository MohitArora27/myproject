package com.bookeshopping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bookeshopping.bean.Login;
import com.bookeshopping.dao.LoginDAO;

public class LoginServiceImpl implements LoginService{
	@Autowired
	private LoginDAO loginDAO;

	@Transactional(readOnly = true, propagation=Propagation.SUPPORTS)
	
	public Login authenticateUser(Login login) {
		// TODO Auto-generated method stub
		return loginDAO.authenticateUser(login);
	}

}
