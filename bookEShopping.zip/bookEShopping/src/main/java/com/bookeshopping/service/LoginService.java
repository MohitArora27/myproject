package com.bookeshopping.service;

import com.bookeshopping.bean.Login;

public interface LoginService {

	public Login authenticateUser(Login login);

	public String getUserType(Login login);
	}
